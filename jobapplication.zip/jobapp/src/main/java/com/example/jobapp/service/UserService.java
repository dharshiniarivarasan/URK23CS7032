package com.example.jobapp.service;

import com.example.jobapp.model.User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class UserService {

    private final Map<String, User> users = new HashMap<>();

    public User findByUsername(String username) {
        return users.get(username);
    }

    public void registerUser(User user) {
        users.put(user.getUsername(), user);
    }
}
