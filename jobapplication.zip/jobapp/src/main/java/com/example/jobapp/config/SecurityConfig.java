@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
            .antMatchers("/login", "/register").permitAll() // Allow access to login and register pages
            .anyRequest().authenticated() // Authenticate all other requests
            .and()
            .formLogin() // Enable form-based login
            .permitAll();
    }
}
