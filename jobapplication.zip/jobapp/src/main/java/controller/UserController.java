package com.example.jobapp.controller;

import com.example.jobapp.model.User;  // Import your User model
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller  // This annotation tells Spring that this is a controller class
public class UserController {

    // Mapping for registration page
    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register";  // This will search for register.html in the templates folder
    }

    // Handling the registration form submission
    @PostMapping("/register")
    public String registerUser(User user) {
        // Here you can save the user to a database or perform some actions.
        // For now, we're just printing the username for simplicity.
        System.out.println("User Registered: " + user.getUsername());
        return "redirect:/login";  // Redirecting to the login page after registration
    }

    // Mapping for login page
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";  // This will look for login.html in the templates folder
    }

    // Handling the login form submission
    @PostMapping("/login")
    public String loginUser(User user) {
        // Implement authentication logic here (e.g., check username and password)
        System.out.println("User Logged In: " + user.getUsername());
        return "redirect:/dashboard";  // Redirecting to the dashboard after login
    }

    // Mapping for dashboard page
    @GetMapping("/dashboard")
    public String showDashboard() {
        return "dashboard";  // This will look for dashboard.html in the templates folder
    }
}
